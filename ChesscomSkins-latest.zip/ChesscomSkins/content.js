const PIECES = [
  "wk","wq","wr","wb","wn","wp",
  "bk","bq","br","bb","bn","bp"
];

let SKIN_DEFINITIONS = {
  "none": {
    type: "none"
  }
};

let BOARD_STYLES = {};

// Переменные для новых функций
let glowIntensity = 1;
let boardStyleTag = null;
let particleStyleTag = null;
let animationStyleTag = null;
let tournamentMode = false;
let currentTournamentSkin = null;
let tournamentListenerAttached = false;
let effectsEnabled = false;

// Загрузка доступных скинов из конфига
async function loadSkinsConfig() {
  try {
    const url = chrome.runtime.getURL("assets/skins.json");
    const response = await fetch(url);
    const config = await response.json();
    
    if (config.skins && Array.isArray(config.skins)) {
      config.skins.forEach(skin => {
        SKIN_DEFINITIONS[skin.id] = {
          type: "image",
          path: `assets/${skin.folder}`,
          name: skin.name,
          description: skin.description
        };
      });
    }
  } catch (error) {
    console.warn("[ChesscomSkins] Не удалось загрузить конфиг скинов:", error);
  }
}

// Загрузка конфига (доска и стили)
async function loadFullConfig() {
  try {
    const url = chrome.runtime.getURL("assets/config.json");
    const response = await fetch(url);
    const config = await response.json();
    
    if (config.boardStyles && Array.isArray(config.boardStyles)) {
      config.boardStyles.forEach(style => {
        BOARD_STYLES[style.id] = style;
      });
    }
  } catch (error) {
    console.warn("[ChesscomSkins] Не удалось загрузить полный конфиг:", error);
  }
}

// Инициализация конфигов при загрузке
const configReady = Promise.all([loadSkinsConfig(), loadFullConfig()]);

function getDefaultSkinId() {
  return Object.keys(SKIN_DEFINITIONS).find((id) => id !== "none") || null;
}

const EFFECT_DEFINITIONS = {
  "minimal": {
    type: "filter",
    filter: "saturate(1.02)",
    ringColor: "rgba(255,255,255,0.8)",
    glowSize: 4,
    ringAnimation: "ringSoft 1.8s ease-in-out infinite"
  },
  "native-ember": {
    type: "filter",
    filter: "hue-rotate(-12deg) saturate(1.2) brightness(1.02)",
    ringColor: "rgba(255,120,60,0.85)",
    glowSize: 8
  },
  "native-frost": {
    type: "filter",
    filter: "hue-rotate(185deg) saturate(1.2) brightness(1.05)",
    ringColor: "rgba(110,190,255,0.85)",
    glowSize: 8
  },
  "native-neon": {
    type: "filter",
    filter: "hue-rotate(270deg) saturate(1.3) brightness(1.05)",
    ringColor: "rgba(210,120,255,0.85)",
    glowSize: 10
  },
  "legendary-ember": {
    type: "filter",
    filter: "saturate(1.3) brightness(1.05)",
    ringColor: "rgba(255,180,60,0.9)",
    glowSize: 12
  },
  "none": {
    type: "none"
  }
};

let skinStyleTag = null;
let effectStyleTag = null;
let lastAppliedSkin = null;
let lastAppliedEffect = null;
let lastAppliedTarget = null;
let overlayStyleTag = null;
let skinsEnabled = false;
let activeSkinPath = null;
let capturedObserver = null;
let capturedObserverRetry = null;
let goodLuckObserver = null;

function applySkin(skinName, skinPath) {
  if (lastAppliedSkin === skinName && activeSkinPath === skinPath) return;
  lastAppliedSkin = skinName;

  if (skinStyleTag) skinStyleTag.remove();
  if (!skinName || skinName === "none") {
    activeSkinPath = null;
    return;
  }

  skinStyleTag = document.createElement("style");
  const definition = SKIN_DEFINITIONS[skinName];
  if ((!definition || definition.type === "none") && !skinPath) return;

  let css = "";
  const resolvedPath = skinPath || definition.path;
  if (resolvedPath) {
    activeSkinPath = resolvedPath;
    PIECES.forEach(piece => {
      const url = chrome.runtime.getURL(`${resolvedPath}/${piece}.png`);
      css += `
        .piece.${piece},
        .promotion-piece.${piece},
        .captured-pieces .piece.${piece},
        .captured-piece.${piece},
        .captured-piece .piece.${piece},
        .captured .piece.${piece},
        [class*="captured"] .piece.${piece},
        .captured-pieces [data-piece="${piece}"],
        .captured-pieces [class*="piece"][data-piece="${piece}"],
        [class*="captured"] [data-piece="${piece}"],
        .captured-piece[data-piece="${piece}"] {
          background-image: url("${url}") !important;
          background-size: contain !important;
          background-repeat: no-repeat !important;
          background-position: center !important;
        }
      `;
    });
  }

  skinStyleTag.textContent = css;
  document.head.appendChild(skinStyleTag);
  updateCapturedImages();
  ensureCapturedObserver();
}

function ensureCapturedObserver() {
  if (capturedObserver) return;

  let updateScheduled = false;
  const debouncedUpdate = () => {
    if (updateScheduled) return;
    updateScheduled = true;
    requestAnimationFrame(() => {
      updateCapturedImages();
      updateScheduled = false;
    });
  };

  const tryAttach = () => {
    const targets = document.querySelectorAll('.captured-pieces, [class*="captured"], .board');
    if (!targets.length) {
      if (!capturedObserverRetry) {
        capturedObserverRetry = setTimeout(() => {
          capturedObserverRetry = null;
          tryAttach();
        }, 500);
      }
      return;
    }

    if (capturedObserverRetry) {
      clearTimeout(capturedObserverRetry);
      capturedObserverRetry = null;
    }

    capturedObserver = new MutationObserver(debouncedUpdate);
    targets.forEach((node) => capturedObserver.observe(node, { childList: true, subtree: true }));
  };

  tryAttach();
}

function updateCapturedImages() {
  if (!activeSkinPath) return;
  const elements = document.querySelectorAll(
    ".captured-pieces [data-piece], [class*=\"captured\"] [data-piece], .captured-pieces .piece, [class*=\"captured\"] .piece"
  );
  elements.forEach((el) => {
    let piece = el.dataset?.piece;
    if (!piece) {
      const classMatch = PIECES.find((code) => el.classList.contains(code));
      piece = classMatch || null;
    }
    if (!piece) return;
    const url = chrome.runtime.getURL(`${activeSkinPath}/${piece}.png`);
    if (el.tagName === "IMG") {
      if (el.src !== url) el.src = url;
    } else {
      el.style.backgroundImage = `url("${url}")`;
      el.style.backgroundSize = "contain";
      el.style.backgroundRepeat = "no-repeat";
      el.style.backgroundPosition = "center";
    }
  });
}

function applyEffect(effectName, targetName) {
  // Сбрасываем кэш для переприменения при изменении интенсивности
  if (lastAppliedEffect === effectName && lastAppliedTarget === targetName && !arguments[2]) {
    // Пропускаем только если не форсированное обновление
  }
  lastAppliedEffect = effectName;
  lastAppliedTarget = targetName;

  if (effectStyleTag) effectStyleTag.remove();
  effectStyleTag = null;
  
  if (!effectName || effectName === "none") return;
  // если эффекты временно отключены (оптимизация), не применять
  if (!effectsEnabled) return;

  effectStyleTag = document.createElement("style");
  const definition = EFFECT_DEFINITIONS[effectName];
  if (!definition || definition.type === "none") return;

  const glowSize = (definition.glowSize || 6) * glowIntensity;
  const ringColor = definition.ringColor || "rgba(255,120,60,0.8)";

  const glowTargets = targetName === "royal"
    ? [".piece.wk", ".piece.wq", ".piece.bk", ".piece.bq"]
    : [".piece", ".promotion-piece"];
  
  const glowTargetSelector = glowTargets.join(", ");

  // Применяем свечение сразу через filter + drop-shadow
  let css = `
    ${glowTargetSelector} {
      filter: ${definition.filter} drop-shadow(0 0 ${glowSize}px ${ringColor}) !important;
      transition: filter 0.3s ease;
    }

    /* Отключаем эффекты для захваченных фигур */
    .captured .piece,
    .captured-piece,
    .captured-pieces .piece,
    [class*="captured"] .piece {
      filter: none !important;
    }
  `;

  effectStyleTag.textContent = css;
  document.head.appendChild(effectStyleTag);
}

function disableSkins() {
  if (skinStyleTag) skinStyleTag.remove();
  if (effectStyleTag) effectStyleTag.remove();
  skinStyleTag = null;
  effectStyleTag = null;
  lastAppliedSkin = null;
  lastAppliedEffect = null;
  lastAppliedTarget = null;
  if (capturedObserver) {
    capturedObserver.disconnect();
    capturedObserver = null;
  }
  if (capturedObserverRetry) {
    clearTimeout(capturedObserverRetry);
    capturedObserverRetry = null;
  }
  stopGoodLuckObserver();
}

function clampIntensity(value, fallback = 1) {
  const numeric = Number(value);
  if (Number.isFinite(numeric)) {
    return Math.min(1, Math.max(0.1, numeric));
  }
  return fallback;
}

async function initializeFromStorage() {
  try {
    await configReady;
  } catch (error) {
    console.warn("[ChesscomSkins] Конфиги загружены с ошибками:", error);
  }

  chrome.storage.sync.get(
    [
      "enabled",
      "activeSkin",
      "activeEffect",
      "activeTarget",
      "activeSkinPath",
      "activeSet",
      "boardStyle",
      "glowIntensity",
      "enabledFeatures"
    ],
    (data) => {
      skinsEnabled = !!data.enabled;
      glowIntensity = clampIntensity(data.glowIntensity, glowIntensity);
      effectsEnabled = skinsEnabled; // включаем эффекты только если включено расширение

      const defaultSkin = getDefaultSkinId();
      let activeSkin = data.activeSkin || defaultSkin;
      let activeEffect = data.activeEffect || "none";
      const activeTarget = data.activeTarget || "all";
      const skinPath = data.activeSkinPath;

      if (data.activeSet && !activeSkin && !activeEffect) {
        if (SKIN_DEFINITIONS[data.activeSet]) {
          activeSkin = data.activeSet;
        } else if (EFFECT_DEFINITIONS[data.activeSet]) {
          activeEffect = data.activeSet;
        }
      }

        if (skinsEnabled) {
          applySkin(activeSkin || defaultSkin, skinPath || null);
          if (activeEffect && activeEffect !== "none") {
            applyEffect(activeEffect, activeTarget);
          } else {
            applyEffect("none", activeTarget);
          }
          applyBoardStyle(data.boardStyle || "default");

          const features = data.enabledFeatures || {};
          enablePieceAnimation(!!features.animation);
          enableTournamentMode(!!features.tournament);
        }
    }
  );
}

initializeFromStorage();

chrome.storage.onChanged.addListener((changes) => {
  if (changes.enabled && changes.enabled.newValue === false) {
    skinsEnabled = false;
    disableSkins();
    return;
  }

  if (changes.enabled && changes.enabled.newValue === true) {
    skinsEnabled = true;
    chrome.storage.sync.get(
      ["activeSkin", "activeEffect", "activeTarget", "activeSkinPath", "boardStyle", "glowIntensity", "enabledFeatures"],
      (data) => {
      const defaultSkin = getDefaultSkinId();
      applySkin(data.activeSkin || defaultSkin, data.activeSkinPath || null);
      applyEffect(data.activeEffect || "none", data.activeTarget || "all");
      applyBoardStyle(data.boardStyle || "default");
      if (data.glowIntensity) setGlowIntensity(data.glowIntensity);
      const features = data.enabledFeatures || {};
      enablePieceAnimation(!!features.animation);
      enableTournamentMode(!!features.tournament);
      watchForGameStart();
    });
    return;
  }

  if (!skinsEnabled) return;

  if (changes.activeSkin && changes.activeSkin.newValue) {
    chrome.storage.sync.get("activeSkinPath", (stored) => {
      applySkin(changes.activeSkin.newValue, stored.activeSkinPath || null);
    });
  }

  if (changes.activeEffect && changes.activeEffect.newValue) {
    chrome.storage.sync.get("activeTarget", (stored) => {
      applyEffect(changes.activeEffect.newValue, stored.activeTarget || "all");
    });
  }

  if (changes.activeSkinPath && changes.activeSkinPath.newValue) {
    chrome.storage.sync.get("activeSkin", (data) => {
      const defaultSkin = getDefaultSkinId();
      applySkin(data.activeSkin || defaultSkin, changes.activeSkinPath.newValue || null);
    });
  }

  if (changes.activeTarget && changes.activeTarget.newValue) {
    chrome.storage.sync.get("activeEffect", (stored) => {
      applyEffect(stored.activeEffect || "none", changes.activeTarget.newValue);
    });
  }

});

let lastOverlayAt = 0;
let hasShownGoodLuck = false;
let goodLuckOverlayNode = null;

function ensureOverlayStyles() {
  if (overlayStyleTag) return;
  overlayStyleTag = document.createElement("style");
  overlayStyleTag.textContent = `
    .good-luck-overlay {
      position: fixed;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 9999;
      pointer-events: none;
      font-family: "Inter", sans-serif;
      font-size: clamp(32px, 6vw, 72px);
      font-weight: 700;
      color: rgba(255, 240, 210, 0.95);
      text-shadow: 0 0 20px rgba(255, 170, 80, 0.85);
      animation: goodLuckFade 3.2s ease-out forwards;
      background: radial-gradient(circle, rgba(20,10,0,0.35) 0%, rgba(0,0,0,0) 70%);
    }

    @keyframes goodLuckFade {
      0% { opacity: 0; transform: translateY(20px) scale(0.98); }
      20% { opacity: 1; transform: translateY(0) scale(1); }
      70% { opacity: 1; }
      100% { opacity: 0; transform: translateY(-10px) scale(1.02); }
    }
  `;
  document.head.appendChild(overlayStyleTag);
}

function showGoodLuckOverlay() {
  if (!skinsEnabled) return;
  if (hasShownGoodLuck) return;
  const now = Date.now();
  if (now - lastOverlayAt < 5000) return;
  lastOverlayAt = now;
  ensureOverlayStyles();

  const overlay = document.createElement("div");
  overlay.className = "good-luck-overlay";
  overlay.textContent = "Good luck";
  document.body.appendChild(overlay);
  goodLuckOverlayNode = overlay;
  setTimeout(() => {
    overlay.remove();
    if (goodLuckOverlayNode === overlay) {
      goodLuckOverlayNode = null;
    }
  }, 3400);
  hasShownGoodLuck = true;
  if (goodLuckObserver) {
    goodLuckObserver.disconnect();
    goodLuckObserver = null;
  }
}

function watchForGameStart() {
  if (!skinsEnabled) return;
  if (window.location.pathname.includes("/analysis")) return;
  
  const maybeShow = () => {
    const board = document.querySelector(".board, .board-area, .board-container, chess-board");
    if (board) {
      showGoodLuckOverlay();
      return true;
    }
    return false;
  };

  // Сначала пробуем сразу
  if (maybeShow()) return;
  
  // Если не нашли доску - проверяем периодически вместо тяжёлого MutationObserver
  let attempts = 0;
  const maxAttempts = 20;
  const checkInterval = setInterval(() => {
    attempts++;
    if (maybeShow() || attempts >= maxAttempts) {
      clearInterval(checkInterval);
    }
  }, 500);
}

function stopGoodLuckObserver() {
  if (goodLuckObserver) {
    goodLuckObserver.disconnect();
    goodLuckObserver = null;
  }
  if (goodLuckOverlayNode) {
    goodLuckOverlayNode.remove();
    goodLuckOverlayNode = null;
  }
  hasShownGoodLuck = false;
}

// ========== НОВЫЕ ФУНКЦИИ ==========

function applyBoardStyle(styleId) {
  if (boardStyleTag) boardStyleTag.remove();
  boardStyleTag = null;
  if (!styleId || styleId === "default" || !BOARD_STYLES[styleId]) {
    loadDefaultBoardStyle();
    return;
  }

  const style = BOARD_STYLES[styleId];
  boardStyleTag = document.createElement("style");
  
  // Chess.com использует классы вида square-11, square-12 и т.д. с координатами
  // Светлые клетки: сумма координат чётная, тёмные: нечётная
  let lightSquares = [];
  let darkSquares = [];
  for (let file = 1; file <= 8; file++) {
    for (let rank = 1; rank <= 8; rank++) {
      const selector = `.square-${file}${rank}`;
      if ((file + rank) % 2 === 0) {
        darkSquares.push(selector);
      } else {
        lightSquares.push(selector);
      }
    }
  }
  
  let css = `
    /* Chess.com board squares */
    ${lightSquares.join(",\n    ")} {
      background-color: ${style.lightColor} !important;
    }
    
    ${darkSquares.join(",\n    ")} {
      background-color: ${style.darkColor} !important;
    }
  `;
  
  // Для neon стиля добавляем свечение
  if (styleId === "neon" && style.glowColor) {
    css += `
    ${lightSquares.join(",\n    ")} {
      box-shadow: inset 0 0 10px ${style.glowColor} !important;
    }
    ${darkSquares.join(",\n    ")} {
      box-shadow: inset 0 0 15px ${style.glowColor} !important;
    }
    `;
  }
  
  boardStyleTag.textContent = css;
  document.head.appendChild(boardStyleTag);
}

function loadDefaultBoardStyle() {
  // Не применяем стили по умолчанию - используем родные стили chess.com
  if (boardStyleTag) {
    boardStyleTag.remove();
    boardStyleTag = null;
  }
}

// Интенсивность свечения (умножитель на opacity эффектов)
function setGlowIntensity(intensity) {
  glowIntensity = clampIntensity(intensity, glowIntensity);
  // Форсируем переприменение эффекта
  if (lastAppliedEffect && lastAppliedEffect !== "none") {
    const effect = lastAppliedEffect;
    const target = lastAppliedTarget || "all";
    lastAppliedEffect = null; // Сбрасываем чтобы обойти проверку
    applyEffect(effect, target);
  }
}

// Анимации фигур (дыхание) - используем filter вместо transform чтобы не ломать позиционирование
function enablePieceAnimation(enabled) {
  if (animationStyleTag) animationStyleTag.remove();
  animationStyleTag = null;
  if (!enabled) return;
  
  animationStyleTag = document.createElement("style");
  animationStyleTag.textContent = `
    .piece, .promotion-piece {
      animation: pieceBreathe 3s ease-in-out infinite;
    }
    
    @keyframes pieceBreathe {
      0%, 100% {
        filter: brightness(1) drop-shadow(0 0 0 transparent);
      }
      50% {
        filter: brightness(1.05) drop-shadow(0 0 3px rgba(255,200,100,0.3));
      }
    }
  `;
  document.head.appendChild(animationStyleTag);
}

// Оптимизированные частицы при ходах
function spawnParticles(x, y, type = "normal") {
  const container = document.querySelector(".chesscom-skins-overlay") || overlayRoot;
  if (!container) return;
  
  const particleCount = type === "capture" ? 8 : 4;
  
  for (let i = 0; i < particleCount; i++) {
    const particle = document.createElement("div");
    particle.className = "particle";
    particle.style.left = x + "px";
    particle.style.top = y + "px";
    
    const angle = (Math.PI * 2 * i) / particleCount;
    const velocity = 2 + Math.random() * 3;
    const vx = Math.cos(angle) * velocity;
    const vy = Math.sin(angle) * velocity;
    
    particle.style.setProperty("--vx", vx);
    particle.style.setProperty("--vy", vy);
    
    const duration = 600 + Math.random() * 400;
    particle.style.animation = `particleFloat ${duration}ms ease-out forwards`;
    
    container.appendChild(particle);
    
    setTimeout(() => particle.remove(), duration);
  }
}

// Режим турнамента (случайный скин каждую новую игру)
function enableTournamentMode(enabled) {
  tournamentMode = enabled;
  if (enabled) {
    selectRandomSkin();
    if (!tournamentListenerAttached) {
      window.addEventListener("beforeunload", selectRandomSkin);
      tournamentListenerAttached = true;
    }
  } else if (tournamentListenerAttached) {
    window.removeEventListener("beforeunload", selectRandomSkin);
    tournamentListenerAttached = false;
  }
}

function selectRandomSkin() {
  const skins = Object.keys(SKIN_DEFINITIONS).filter(id => id !== "none");
  if (skins.length === 0) return;
  
  const randomSkin = skins[Math.floor(Math.random() * skins.length)];
  currentTournamentSkin = randomSkin;
  
  chrome.storage.sync.set({
    activeSkin: randomSkin,
    activeSet: randomSkin
  });
  
  console.log("[ChesscomSkins Tournament] Selected: " + randomSkin);
}

// Добавляем слушатель на новые игры в режиме турнамента
if (tournamentMode) {
  window.addEventListener("beforeunload", () => {
    if (tournamentMode) {
      selectRandomSkin();
    }
  });
}

// ========== ОБРАБОТЧИК СООБЩЕНИЙ ОТ POPUP ==========
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "setGlowIntensity") {
    setGlowIntensity(request.intensity);
    sendResponse({success: true});
  } else if (request.action === "setBoardStyle") {
    applyBoardStyle(request.style);
    sendResponse({success: true});
  } else if (request.action === "setFeature") {
    const feature = request.feature;
    const enabled = request.enabled;
    
    if (feature === "animation") {
      enablePieceAnimation(enabled);
    } else if (feature === "particles") {
      // Частицы уже применяются автоматически в spawnCrackEffect
    } else if (feature === "tournament") {
      enableTournamentMode(enabled);
    }
    sendResponse({success: true});
  }
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.boardStyle && changes.boardStyle.newValue) {
    applyBoardStyle(changes.boardStyle.newValue);
  }

  if (changes.glowIntensity) {
    setGlowIntensity(changes.glowIntensity.newValue);
  }

  if (changes.enabledFeatures) {
    const features = changes.enabledFeatures.newValue || {};
    enablePieceAnimation(!!features.animation);
    enableTournamentMode(!!features.tournament);
  }
});

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    if (skinsEnabled) watchForGameStart();
  });
} else {
  if (skinsEnabled) watchForGameStart();
}
